# For Office hours
* What is backward Euler?
    * How does Adam's Method work?
    * what is explicit vs. implicit?
* What is d_new and s_new?
* Where does Newton's method come into play, do we only use it once?
* How do the Three ODEs model the reaction?
* Why is it a matrix?
* Are we solving Ax=B? What is A, x and b?
* Maybe ask about the midterm as well?
